
# gulp 插件
- gulp插件都以 `gulp-` 开头
- 一般将一些重复的操作划分为不同的任务，例如：压缩js是一个任务，压缩css是一个任务
- 插件使用过程
	1. 先有个需求
	2. 根据需求找到对应插件
	3. 找到这个插件的官方地址
	4. 根据官方地址中的基本使用，做个简单的demo

- gulp-load-plugins
    + 自动从package.json中加载任意Gulp插件然后把它们附加到一个对象上
    + 延迟加载功能，提高了插件的性能,因为插件在使用的时候才会被加载进来
    + 不要package.json里未被使用的插件影响性能
        * 前提是： 需要把不用的插件清理掉，不用到就不要安装
    ```
    import gulpLoadPlugins from 'gulp-load-plugins';
	const plugins = gulpLoadPlugins();

    gulp.task('js', ()=>{
        return gulp.src('js/*.js')
            .pipe(plugins.jshint())
            .pipe(plugins.jshint.reporter('default'))
            .pipe(plugins.uglify())
            .pipe(plugins.concat('app.js'))
            .pipe(gulp.dest('build'));
        });
    ```




## gulp 插件
- npm install

```
npm install gulp-babel babel-core babel-preset-es2015 -D

```

- import from

```
    // 编译 sass
    import sass from 'gulp-sass';
    import autoprefixer from 'gulp-autoprefixer'; // 浏览器前缀
    import spriter from 'gulp-css-spriter'; // 合并精灵图
    import concat from 'gulp-concat'; // 合并文件
    import csso from 'gulp-csso'; // 压缩CSS，先合并，后压缩
    import rename from 'gulp-rename';

    import imagemin from 'gulp-imagemin'; // 压缩PNG, JPEG, GIF and SVG，耗性能
    import del from ('del');





    // 增量编译
    import cached from 'gulp-cached';
    import plumber from 'gulp-plumber'; // 错误信息
    


    // es6 转 es2015
    import babel from 'gulp-babel';
    import uglify from 'gulp-uglify';


    // 服务器
    import browserSync from 'browser-sync';
    const reload = browserSync.reload;


    const dev = true; // 开发环境

```

## Sass 预编译CSS

```
gulp.task('sass', ()=>{
    return gulp.src('sass/*.scss', { cwd: 'app' })
        .pipe(plumber(plumber.options))
        .pipe( sourcemaps.init() )
        .pipe( sass({
            outputStyle: 'expanded',
            precision: 10,
            errLogToConsole: true
            // paths: [path.join(__dirname, 'scss', 'includes')]
        }) )
        .pipe( autoprefixer({
            browsers: ['last 2 versions'],
            cascade: false
        }) )

        .on('error', notify.onError( (error)=>{
            return `Compile Sass File:${error.message}`;
        }))

        .pipe( csso() )
        .pipe( rename({
            basename: 'style',
            suffix: '.min'
        }) )
        .pipe(sourcemaps.write('.'))
        .pipe( gulp.dest('css') )
        .pipe( reload({ stream: true }) )
});
```


## less

```
gulp.task('less', ()=>{
    return gulp.src('./src/less/*.less')
        .pipe( less() ) // less文件编译成css文件
        .pipe( concat('styles.css') ) //合并编译后的css文件，并指定名称为styles.css
        .pipe( gulp.dest('./build/css') ) // 输出合并后的非压缩版css文件

        .pipe( csso() ) // 压缩合并后的css文件
        .pipe( rename({
            suffix: '.min'
        }) )
        .pipe(gulp.dest('./build/css')) // 压缩后输出
});

```


## cssmin 压缩CSS

```
gulp.task('cssmin', ['sass'], ()=>{
    return gulp.src('css/*.css')
        .pipe( spriter({
            //要生成的精灵图的路径和名字
            'spriteSheet': './dist/images/spritesheet.png',
            //css中引用的图片的路径
            'pathToSpriteSheetFromCSS': '../images/spritesheet.png'
        }) )
        .pipe( concat('style.css') )
        .pipe( csso() )
        .pipe( rename({
            suffix: '.min'
        }) )
        .pipe( gulp.dest('css') )
        .pipe( reload({
            stream: true
        }) )
});

```


## imagemin 压缩图片

```
gulp.task('imagemin', ()=>{
    return gulp.src('app/images/**/*.{jpg,png,gif,svg}')
        .pipe( plumber() )
        .pipe( cached() )
        .pipe( imagemin({
            optimizationLevel: 7,
            progressive: true,
            interlaced: true,
            // don't remove IDs from SVGs, they are often used
            // as hooks for embedding and styling
            svgoPlugins: [{cleanupIDs: false}]
        }) )
        .pipe( gulp.dest('app/dist') )
        .pipe( reload({
            steam: true
        }) )
});

```



## ES6 转 ES2015

```
gulp.task('es6', ()=>{
    return gulp.src('es6/**.*.js')
        .pipe(plumber(plumberConfig))
        .pipe(webpackStream(webpackConfig, webpack, done))
        .pipe(sourcemaps.init())
        .pipe(babel({
            presets: ['es2015']
        }))
        .pipe(uglify({
            sequences     : true,
            properties    : true,
            dead_code     : true,
            drop_debugger : true,
            unsafe        : false,
            conditionals  : true,
            comparisons   : true,
            evaluate      : true,
            booleans      : true,
            loops         : true,
            unused        : true,
            hoist_funs    : true,
            hoist_vars    : false,
            if_return     : true,
            join_vars     : true,
            cascade       : true,
            side_effects  : true,
            warnings      : true
        }))
        .pipe(rename({
          extname: '.min.js'
        }))
        .pipe(sourcemaps.write('.'))
        .pipe(gulp.dest('dist/js'))
});

```



## jsmin
```
gulp.task('jsmin', ()=>{
    return gulp.src('js/*.js')
        .pipe( uglify() )
        .pipe( rename({
            suffix: '.min'
        }) )
        .pipe( gulp.dest('js') )
        .pipe( reload({
            steam: true
        }) )
});
```


## clean
```
gulp.task('clean', (done)=>{
    return del(['app/css', 'app/js'], done)
});
```



## html
```
gulp.task('html', ()=>{
    return gulp.src('app/**/*.html')
        .pipe( plumber() )
        .pipe( htmlmin({
            removeComments: true,
            collapseWhitespace: true,
            collapseBooleanAttributes: true,
            removeAttributeQuotes: true,
            removeRedundantAttributes: true,
            removeEmptyAttributes: true,
            removeScriptTypeAttributes: true,
            removeStyleLinkTypeAttributes: true,
            removeOptionalTags: false,
            minifyJS: true, //压缩页面JS
            minifyCSS: true //压缩页面CSS
        }) )
        .pipe( gulp.dest('app/dist') )
        .pipe( reload({
            stream: true
        }) )
});
```



## copy
```
const entry ={
    jquery:[
        'node_modules/jquery/dist/jquery.js',
        'node_modules/jquery/dist/jquery.min.js'
    ],
    popper:[
        'node_modules/popper.js/dist/popper.js', 'node_modules/popper.js/dist/popper.min.js'
    ],
    bootstrap: [
        'node_modules/bootstrap/dist/**/*',
        '!**/npm.js',
        '!**/bootstrap-theme.*',
        '!**/*.map'
    ],
    easing: 'node_modules/jquery.easing/*.js',
    lineicon: ['node_modules/simple-line-icons/*/*'],
    fontAwesome: [
        'node_modules/font-awesome/**',
        '!node_modules/font-awesome/**/*.map',
        '!node_modules/font-awesome/.npmignore',
        '!node_modules/font-awesome/*.txt',
        '!node_modules/font-awesome/*.md',
        '!node_modules/font-awesome/*.json'
    ]

};
gulp.task('copy', ()=>{
    gulp.src(entry.jquery)
        .pipe( gulp.dest(vendor/jquery) )

    gulp.src(entry.popper)
        .pipe( gulp.dest('vendor/popper') )

    gulp.src(entry.bootstrap)
    .pipe( gulp.dest('vendor/bootstrap') )

    gulp.src(entry.easing)
    .pipe( gulp.dest('vendorjquery-easing') )

    gulp.src(entry.lineicon)
    .pipe( gulp.dest('vendor/simple-line-icons') )

    gulp.src(entry.fontAwesome)
    .pipe( gulp.dest('vendor/font-awesome') )
});
```


## server
```
gulp.task('serve', ()=>{
    browserSync.init({
        server: {
            baseDir: './app'
        },
        notify:false
    });
});



// watch
gulp.task('watch', ()=>{
    gulp.watch('sass/*.scss', ['sass']);
    gulp.watch('css/*.css', ['cssmin']);
    gulp.watch('js/*.js', ['jsmin']);

    gulp.watch('app/*.html', ['html']);
});



// build
import sequence from 'gulp-sequence';
gulp.task('build', (done)=>{
    sequence(['clean', 'sass', 'imagemin', 'es6', 'js',], 'copy', 'clean', done);
});


// dev
gulp.task('dev', ()=>{
    sequence(['watch'], 'serve', done)
})



// default task
gulp.task('default', ['sass', 'cssmin', 'jsmin', 'copy']);

// 分离任务 default
gulp.task('dev', ['build']);
```