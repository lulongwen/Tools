

    let a= 'hello gulp';
    export default a;