"use strict";

var first = document.querySelector('h1');

document.onclick = function () {

		first.textContent = "这是ES6DOM改变的文字";

		var name = "beatifuly";

		console.log(name);
		console.log('hello es6');
};