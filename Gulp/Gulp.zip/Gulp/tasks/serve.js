
    import gulp from 'gulp';
    import browserSync from 'browser-sync';
    let reload = browserSync.reload;

    import {paths} from './config';
    

// task
    gulp.task('server', ()=>{
        browserSync({
            server: {
                baseDir: './app',
                index: "index.html"
            },
            port: '8088',
            open: false //  'local' 自动打开本地服务器
        });

        gulp.watch(paths.html.entry, ['html']);
        gulp.watch(paths.less.entry, ['less']);
        gulp.watch(paths.js.entry, ['js']);

        /*
            // compile styles (reloads them automatically)
            gulp.watch(config.paths.app + '/sass/**', ['compile-styles']);

            // reload on change
            gulp.watch([
                config.paths.app + '/js/**',
                config.paths.app + '/views/**',
                config.paths.app + '/images/**',
                ], function (e) {
                return gulp.src(e.path).pipe(browserSync.reload({stream: true}));
            });
        */
    });

    