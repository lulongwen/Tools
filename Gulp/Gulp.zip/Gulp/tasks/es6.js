
    /* gulp-babel 编译 ES6
        npm i gulp-babel babel-preset-es2015 babel-core -D

    */

    import gulp from 'gulp';

    import babel from 'gulp-babel';

    import sourcemaps from 'gulp-sourcemaps';


    // 增量编译
    import cached from 'gulp-cached';

    import remember from 'gulp-remember';


    // 提示信息
    import debug from 'gulp-debug';

    import plumber from 'gulp-plumber';

    import notify from 'gulp-notify';


    // 服务器
    import browserSync from 'browser-sync';
    const reload = browserSync.reload; // 浏览器重载



    gulp.task('es6', ()=>{
        return gulp.src('app/src/es6/**/*.js')
            .pipe( cached('es6') ) // 只传递更改过的文件，放在第一位
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译less'
            }) )
            // .pipe( sourcemaps.init() ) 
            .pipe( babel() )
            // .pipe( sourcemaps.write('./maps') )
            // .pipe( remember('es6') ) // 把所有的文件放回 stream,加上这个是多个文件改变
            .pipe( gulp.dest('app/src/js') )
            .pipe( reload({ stream: true }) )
    });