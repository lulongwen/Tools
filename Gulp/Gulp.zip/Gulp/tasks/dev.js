

    import gulp from 'gulp';

    // 顺序执行任务 gulp-sequence
    import gulpSequence from 'gulp-sequence';

/* task思路：
	- 先清除编译好的文件
	- 后编译 css, js, html，因为 html要引入 css 和 js，所以要在html前面编译
	- 然后启动服务器 serve

	gulp.task('dev', gulpSequence('clean', 'less', 'html', 'js', ['server']));
 */

 	// 开发版
    gulp.task('dev', gulpSequence('less', 'es6', 'html', ['serve']));

    // 上线版
    gulp.task('build', gulpSequence('less-build', 'es6-build', 'html-build', ['serve']));