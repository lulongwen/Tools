

    import gulp from 'gulp';
    import less from 'gulp-less';
    import csso from 'gulp-csso';
    // import rev from 'gulp-rev';

    import {paths} from './config';
    import error from './util/error';
    import debug from 'gulp-debug';

    import browserSync from 'browser-sync';
    let reload = browserSync.reload;

// task
    gulp.task('less', ()=>{
                    // less 入口文件
        return gulp.src(paths.less.entry)
            .pipe( debug({'title': '编译 less'}) )
            .pipe( less(paths.less.settings) ) // 编译less设置
            .on('error', error) // 让 notify处理错误
            // .pipe( rev() )
            .pipe( gulp.dest(paths.less.output) ) // 输出
            // .pipe( rev.manifest() )
            // .pipe( gulp.dest(paths.less.rev) )
            .pipe(reload({ stream:true }));
    });

    gulp.task('less-build', ()=>{
        return gulp.src(paths.less.entry)
            .pipe( less(paths.less.settings) )
            .on('error', error) // 让 notify处理错误
            .pipe( csso() )
            
            // .pipe( rev() )
            .pipe( gulp.dest(paths.less.output) )
            // .pipe( rev.manifest() )
            .pipe( gulp.dest(paths.less.rev) )
    });