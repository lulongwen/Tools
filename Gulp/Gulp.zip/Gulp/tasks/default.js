
    import gulp from 'gulp';

// default task build 
    gulp.task('default', ['dev']);