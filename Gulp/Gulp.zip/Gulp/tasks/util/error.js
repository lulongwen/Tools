

	import notify from 'gulp-notify';

	module.exports = ()=>{

		let args = Array.prototype.slice.call(arguments);
		notify.onError({
			title: 'compile error',
			message: '<%= error %>'
		}).apply(this, args);//替换为当前对象
		this.emit();//提交
	};