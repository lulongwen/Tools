
    // gulp 命令会有 gulpfile.babel.js执行， app & dist 文件夹路径如下
    const app = './app';
    const dist = './dist';

    export const paths = {
        entryFile: app,
        distFile: dist,
        html:{
            entry: `${app}/**/*.html`,
            output: dist,
            options:{
                removeComments: true,//清除HTML注释
                collapseWhitespace: true,//压缩HTML
                collapseBooleanAttributes: true,//省略布尔属性的值 <input checked="true"/> ==> <input />
                removeEmptyAttributes: true,//删除所有空格作属性值 <input id="" /> ==> <input />
                removeScriptTypeAttributes: true,//删除<script>的type="text/javascript"
                removeStyleLinkTypeAttributes: true,//删除<style>和<link>的type="text/css"
                minifyJS: true,//压缩页面JS
                minifyCSS: true//压缩页面CSS
            }
        },
        less: {
            all: `${app}/assets/less/**/*.less`, // all less
            entry: `${app}/assets/less/*.less`, // 编译的less
            output: `${app}/assets/css` , // 打包输出目录
            rev: `${dist}/assets/rev/css`, // md5版本
            options:{ // 编译less的设置

            }
        },
        js: {
            entry: `${app}/assets/js/**/*`,
            output: `${dist}/js`,
            rev: `${dist}/rev/js`
        },
        images: {
            entry: `${app}/assets/images/**/*`,
            output: `${dist}/images`,
            options:{
                
            }
        },
        clean: {
            entry: `${dist}`
        },
        rev: { // use rev to reset html resource url
            entry: `*.html`, // root index.html
            output: ``,
            revJSON: `${dist}/rev/**/*.json`,
        }


    };