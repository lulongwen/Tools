
    import gulp from 'gulp';


    // 增量编译
    import cached from 'gulp-cached';
    // const remember = require('gulp-remember');
    

    // htmlmin 压缩参数
    // https://github.com/kangax/html-minifier#user-content-options-quick-reference
    import htmlmin from 'gulp-htmlmin';


    import plumber from 'gulp-plumber';
    import debug from 'gulp-debug';
    import notify from 'gulp-notify';


    import {paths} from './config';


    import browserSync from 'browser-sync';
    let reload = browserSync.reload;
    

// task
    gulp.task('html', ()=>{
        return gulp.src(paths.html.entry)
            .pipe( cached('html') ) // 只传递更改过的文件，放在第一位
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译 html:',
                showFiles: true, // default
                minimal: true
            }) )
            
            .pipe(reload({ stream:true }))
    });


    gulp.task('html-build', ()=>{
        return gulp.src(paths.html.entry)
            .pipe( cached('html') ) // 只传递更改过的文件，放在第一位
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译 html:',
                showFiles: true, // default
                minimal: true
            }) )

            .pipe( htmlmin(paths.html.options) )
            .pipe( gulp.dest(paths.html.output) )
            .pipe(reload({ stream:true }))
    });