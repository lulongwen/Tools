
	import gulp from 'gulp';
	import {paths} from './config';

	import browserSync from 'browser-sync';
    let reload = browserSync.reload;


	gulp.task('watch', ['server'], ()=>{
	    gulp.watch(paths.html.entry, ['html'], reload);
	    gulp.watch(paths.less.entry, ['less'], reload);
	    gulp.watch(paths.js.entry, ['js'],reload);
	});