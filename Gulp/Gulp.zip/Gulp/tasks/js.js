
    import gulp from 'gulp';
    import rev from 'gulp-rev';
    import uglify from 'gulp-uglify';
    import concat from 'gulp-concat'; // 合并文件

    import babel from 'gulp-babel';
    import es2015 from 'babel-preset-es2015';

    import {paths} from './config';



// task
    gulp.task('js', ()=>{
        return gulp.src( paths.js.entry )
            .pipe( babel({ presets:[es2015]}) )
            .pipe( rev() )
            .pipe( gulp.dest( paths.js.output ) )
            .pipe( rev.manifest() )
            .pipe( gulp.dest( paths.js.rev ) ) //dest hash key json
    });


    gulp.task('js-build', ()=>{
        return gulp.src( paths.js.entry )
            .pipe( babel({ presets:[es2015]}) )
            .pipe( uglify() )
            .pipe( rev() )
            .pipe( gulp.dest( paths.js.output ) )
            .pipe( rev.manifest() )
            .pipe( gulp.dest( paths.js.rev ) ) //dest hash key json
    });