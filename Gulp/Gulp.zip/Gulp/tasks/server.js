
    import gulp from 'gulp';
    import browserSync from 'browser-sync';
    let reload = browserSync.reload;

    import {paths} from './config';
    

// task
    gulp.task('server', ()=>{
        browserSync({
            server: {
                baseDir: './app',
                index: "index.html"
            },
            port: '8088',
            open: false //  'local' 自动打开本地服务器
        });
    });