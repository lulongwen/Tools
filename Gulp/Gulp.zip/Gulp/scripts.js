
    import gulp from 'gulp';
    import gulpif from 'gulp-if'; // gulp中 if判断
    import concat from 'gulp-concat'; // 合并文件
    import named from 'vinyl-named'; // 获取js文件模块，重命名模块 vinyl-named

    import rename from 'gulp-rename'; // 重命名文件
    import uglify from 'gulp-uglify'; // 压缩js
    import livereload from 'gulp-livereload'; // 热更新
    import plumber from 'gulp-plumber'; // 处理文件信息流

    import webpack from 'webpack'; // 打包
    import gulpWebpack from 'webpack-stream'; // stream流

    import {log, colors} from 'gulp-util';
    import args from './util/args.js';


// task
    gulp.task('scripts', ()=>{
    return gulp.src( ['app/js/index.js'] )
        .pipe( plumber({
            errorHandler(){
                // 借助 webpack 去实现错误信息
                console.log('error')
            }
        }) )
        .pipe( named() )
        .pipe( gulpWebpack({
            module:{
                loaders: [
                    {
                        test: /\.js%/,
                        loader: 'babel'
                    }
                ]
            }
        }), null, (err, status)=>{
            log(`Finished ${colors.cyan('script')}`, status.toString({
                chunks: false
            }))
        })
        .pipe( gulp.dest('server/public/js') )
        .pipe( rename({
            basename: 'my',
            extname: '.min.js'
        }) )
        .pipe( uglify({
            compress: { properties: false },
            output: {'quote_keys': true}
        }) )
        .pipe( gulp.dest('server/public/js') )
        .pipe( gulpif(args.watch, livereload()) )
    });
    