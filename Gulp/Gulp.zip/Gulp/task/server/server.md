
[TOC]
# 前端实时可视化

## Browser-sync 浏览器实时刷新
- [browsersync.io](https://www.browsersync.io)

- `npm install gulp browser-sync --save-dev`
	+ [browser-sync 项目依赖](http://www.browsersync.cn/docs/gulp)

- 浏览器和编辑器不需要安装插件，项目优先考虑

- Browser-sync本质是启动一个代理服务器，代理服务器监听文件变化，通过TCP长连接，仅仅对变化的部分进行视图的同步。
- 支持对所有文件的实时更新，单向修改，只能通过修改文件更新页面
- ![browsersync](browsersync.jpg)


###  Browser-sync全局安装
- `npm install -g browser-sync` 全局安装

- 启动browser-sync要在项目文件夹下启动，不要在C盘下启动，否则会导致系统变慢

- 监听多个类型的文件用英文逗号 , 隔开

- 目录层级比较深，可以用 `**`（表示任意目录）匹配，任意目录下任意.css 或 .html文件

- 代理服务器，针对动态网站
```
--files 路径是相对于运行该命令的项目（目录） 
browser-sync start --server --files "css/*.css"

watch 多个文件 
browser-sync start --server --files "css/*.css, *.html"

较深目录匹配
browser-sync start --server --files "**/*.css, **/*.html"

动态网站代理：主机名可以是ip或域名
browser-sync start --proxy "主机名" "css/*.css"

browser-sync start --proxy "lulongwen.com" "css/*.css"
```
---



## livereload
- [livereload.com](http://livereload.com)
	+ 要安装浏览器插件

- `npm install livereload --save-dev` gulp-livereload

- livereload本质是做了F5的操作，支持对所有文件的实时更新

- 单向数据流，只能通过修改文件更新页面

- ![livereload](livereload.jpg)

---



## livestyle
- [livestyle 文档](http://livestyle.io/docs)
- 仅限于样式，用来修改样式，复杂样式的双向修改
- 针对样式实时可视化，支持less，sass，css

- 编辑器和浏览器都要安装插件，二者缺一不可
	+ sublime 安装livestyle
	+ chrome 安装 livestyle
		* chrome开启livestyle，双向绑定
		* 在chrome F12 -Element中修改样式，编辑器的样式也会自动更新
		* 修改后，不用ctrl+S保存，页面也能自动刷新

	+ ![chrome开启livestyle，双向绑定](livestyle.jpg)



## gulp-connect 本地服务器
- [gulp-connect 服务器](https://www.npmjs.com/package/gulp-connect)
- 在本地开启一个websocket 服务，检测文件变化，当文件被修改后触发 livereload 任务，推送消息给浏览器刷新页面

```
import gulp from 'gulp';
import connect from 'gulp-connect';

gulp.task('connect', ()=>{
	connect.server({
		port: 8088,
		root:'app', // 根目录文件夹
		livereload: true // true，文件改变自动刷新页面
	});
});

// 定义一个html task
gulp.task('html', ()=>{
	gulp.src('http/**/*.html')
		.pipe(connect.reload())
});

gulp.task('watch', ()=>{
  gulp.watch(['./app/*.html'], ['html']);
});

gulp.task('default', ['connect', 'watch']);

```