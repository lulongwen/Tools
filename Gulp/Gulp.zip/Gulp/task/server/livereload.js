
	import gulp from 'gulp';
	import less from 'gulp-less';

	import livereload from 'gulp-livereload';
	/* https://github.com/vohof/gulp-livereload
		需要下载件
		- chrome .crx
		- firefox .xpi
	*/


	// less
	gulp.task('less', ()=> {
		gulp.src('less/*.less')
		  .pipe(less())
		  .pipe(gulp.dest('css'))
		  .pipe(livereload());
	});

	gulp.task('watch', ()=>{
		livereload.listen();
		gulp.watch('less/*.less', ['less']);
	});



	// livereload html
	gulp.task('livereload', ()=>{
		// 启动livereload 监听
		livereload.listen();

		// 只监听 根目录下的html文件
		gulp.watch('./*.html', (file)=>{
			console.log(file);
			gulp.src(file.path)
				.pipe(livereload());
		});
	});

