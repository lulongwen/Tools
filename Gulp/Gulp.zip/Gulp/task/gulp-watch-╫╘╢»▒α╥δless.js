    
    /* gulp-watch gulp-less 编译 less
        监听less，只让改变的less文件通过编译
    */
    const gulp = require('gulp');

    // 编译less
    const less = require('gulp-less');


    /* 异常处理
        当 less编译语法错误时，会终止编译和 watch，通常要查看命令提示符窗口才知道
        处理出现编译错误，不终止 编译和 watch事件，并给我们提示
        需要安装 
        gulp-notify  // gulp通知的插件，提示出现的错误
        gulp-plumber  // 防止错误引起管道中断
    */
    // 防止错误引起管道中断，出现错误不中断任务
    const plumber = require('gulp-plumber');

    // gulp通知的插件，提示出现的错误
    const notify = require('gulp-notify');


    // 调试文件流来观察那些文件通过了gulp 管道
    const debug = require('gulp-debug');


    // 只让发生改变的文件通过管道
    const watch = require('gulp-watch');
    /* gulp-watch可以做到和 gulp.watch() 一样监听文件改动
        - 每一次被改动的文件会被 gulp-watch继续向下传递
        - 会自动编译 less的 任务 task
        - 缺点： 无法处理 合并文件 gulp-concat 的任务
    */

    // 合并文件
    const concat = require('gulp-concat');

     

    // 单个文件
    // const entry = './app/less/index.less';

    // 多个文件，以数组形式传入, watch方法路径不要用 './xx'
    // 用 './xx' 开头作为当前路径开始，会导致无法监测到新增文件，所以直接省略掉 './'
    const cfg = {
        entry : ['app/src/less/index.less', 'app/src/less/list.less'],
        output : 'app/src/css'
    };


    // gulp.task()
    gulp.task('less', function(){
    return gulp.src(cfg.entry)
        .pipe( watch(cfg.entry) )
        .pipe( plumber({ // 错误提示
            errorHandle: notify.onError('error: <%= error.message %>')
        }) )
        .pipe( debug({ // 显示编译的文件
            title: '编译less'
        }) )
        .pipe(less())
        // .pipe( concat('all.css') ) // 不会合并文件，只会编译文件
        .pipe( gulp.dest(cfg.output) )
    });