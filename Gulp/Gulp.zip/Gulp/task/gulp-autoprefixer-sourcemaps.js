    
    // gulp
    const gulp = require('gulp');

    // 编译less
    const less = require('gulp-less');


    /* 异常处理
        当 less编译语法错误时，会终止编译和 watch，通常要查看命令提示符窗口才知道
        处理出现编译错误，不终止 编译和 watch事件，并给我们提示
        需要安装 
        gulp-notify  // gulp通知的插件，提示出现的错误
        gulp-plumber  // 防止错误引起管道中断
    */
    // 防止错误引起管道中断，出现错误不中断任务
    const plumber = require('gulp-plumber');

    // gulp通知的插件，提示出现的错误
    const notify = require('gulp-notify');


    // 调试文件流来观察那些文件通过了gulp 管道
    const debug = require('gulp-debug');


    // 合并文件
    const concat = require('gulp-concat');


    /* 过滤修改的文件向下传递，只对修改的文件进行编译
        如果多个文件，会过滤掉没有修改的文件，要配合使用 gulp-remember
    */
    const cached = require('gulp-cached');

    /* gulp-cached & gulp-remember 集合使用
        做到只对修改的文件进行编译，
        又能做到当相关联的文件任意一个发生改变的时候，编译所有的相关文件
    */
    const remember = require('gulp-remember');


    // sourcemaps 转换后代码对应转换前代码的位置
    // 在文件最后一行加上 @ sourceMappingURL=jquery.min.map
    const sourcemaps = require('gulp-sourcemaps');

    // 自动补全浏览器前缀
    const autoprefixer = require('gulp-autoprefixer');


    // 服务器
    const browserSync = require('browser-sync').create();
    const reload = browserSync.reload; // 浏览器重载



    // 多个文件，以数组形式传入, watch方法路径不要用 './xx'
    // 用 './xx' 开头作为当前路径开始，会导致无法监测到新增文件，所以直接省略掉 './'
    const cfg = {
        entry : ['app/src/less/index.less', 'app/src/less/list.less'],
        output : 'app/src/css'
    };


    // gulp.task('less', fn)
    gulp.task('less', function(){
        return gulp.src(cfg.entry)
            .pipe( cached('less') ) // 只传递更改过的文件，放在第一位
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译less'
            }) )
    		
    		.pipe( sourcemaps.init() ) // sourcemaps 初始化
    		.pipe( autoprefixer({
    			browsers: ['last 3 versions'], // 包括ie9
    			cascade: true, // 美化属性值，比如 
    			// -webkit-transform: rotate(45deg);
            	//         transform: rotate(45deg);
    			remove: true // 去掉不必要的前缀，默认 true
    		}) ) // 放在 less编译前
            .pipe(less())
            .pipe( remember('less') ) // 把所有的文件放回 stream
            .pipe( concat('style.css') ) // 合并文件
            .pipe( sourcemaps.write('./maps') )  // 生成 sourcemaps文件，路径为 ./maps
            .pipe( gulp.dest(cfg.output) )
            .pipe( reload({ stream: true }) )
    });


    // watch html
    gulp.task('html', function(){
        return gulp.src('app/**/*.html')
            .pipe( cached('html') ) // 只传递更改过的文件，放在第一位
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译html'
            }) )
            // .pipe( remember('html') ) // 把所有的文件放回 stream，包括没有改变的html
            .pipe( reload({ stream: true }) )
            // .pipe( browserSync.stream({match: "**/*.html"}) )
    })


    // 监听less文件改动，发生改变运行 less task，并重载文件
    gulp.task('serve', ['less'], function(){
        browserSync.init({
            server:{
                baseDir: 'app',
                index: "index.html"
            },
            open: false, // 不自动打开网页
            notify: false // 不显示右上角的提示
        });

        gulp.watch( 'app/src/less/**/*.less', ['less'] );
        // gulp.watch( 'app/**/*.html').on('change', reload);
        gulp.watch( 'app/**/*.html', ['html']);
    })
