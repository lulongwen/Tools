    
    /* gulp 增量编译打包，处理所涉及的所有文件
        - 增量编译操作的是 所有处理过的文件，而不是单个的文件
        - 使用 gulp-cached && gulp-remember 解决增量打包


        gulp 增量编译的4个插件

        gulp-changed // only pass through changed files

        gulp-cached // in-memory file cache, not for operation on sets of files
        gulp-remember // pairs nicely with gulp-cached

        gulp-newer // pass through newer source files only, supports many:1 source:dest

        1 gulp-cached 
            将第一次传递给它的文件保存留在内存中，如果之后执行 task，
            会将传递给它的文件和内存中的文件进行对比，如果相同，就不再将该文件继续向后传递，
            从而做到了只对修改过的文件进行增量编译
            使用限制：
            - gulp-concat 会导致没有改变的文件不会被编译，所以要借助 gulp-remember

        2 gulp-remember
            在内存中缓存所有曾经传递给它的文件，和 gulp-cached的区别是：
            - gulp-cached 改变的文件会向下传递，没改变的文件会直接忽略
            - gulp-remember 将未传递给它的文件进行补足，继续向下传递
            - 因此 gulp-cached 和 gulp-remember结合使用，
                - 做到只对修改过的文件进行编译，
                - 又能做到当相关联的文件任意一个发生改变时，编译所有的相关文件

            - 在第一次合并文件的时候，gulp-remember已经将传递过来的文件缓存在内存中
                - 在后续的 task中，gulp-cached过滤了没有改变的文件，但是 gulp-remember能够通过自己的缓存来补全这些缺失的文件，从而做到正确的合并

            - gulp-cached && gulp-remember结合的优势：
                - gulp-remember缓存的是 less编译后生成的 css文件，只有修改了 less文件才需要重新编译成css文件
                - 其它 less文件对应的 css文件可以直接从 gulp-remember的缓存中读取，而不使用插件的话每次都要重新编译所有的less文件，耗费资源
        
        3 gulp-changed
            - 通过比较源文件和生成文件，调用插件时要传入生成的位置，一般就是最后 gulp.dest() 传入的参数
            - 除非只是简单地复制，所以说基本上没用；如果 task中改变了 文件的后缀名，就需要通过 extension参数来指定新的后缀名，否则插件无法找到生成的文件
            ```
            gulp.task('less', function() {
                gulp.src('./src/*.less')
                    .pipe(changed('./dist', {
                        extension: '.css'
                    }))
                    .pipe(less())
                    .pipe(gulp.dest('./dist'));
            });
            gulp.task('watch', function() {
                gulp.watch('src/*.less', ['less']);
            });
            ```

        4 gulp-newer
            - 用的少
            ```
            gulp.task('less', function() {
                gulp.src('./src/*.less')
                    .pipe(newer('./dist/all.css'))
                    .pipe(less())
                    .pipe(concat('all.css'))
                    .pipe(gulp.dest('./dist'));
            });
            gulp.task('watch', function() {
                gulp.watch('src/*.less', ['less']);
            });
            ```


    */
    const gulp = require('gulp');

    // 编译less
    const less = require('gulp-less');


    /* 异常处理
        当 less编译语法错误时，会终止编译和 watch，通常要查看命令提示符窗口才知道
        处理出现编译错误，不终止 编译和 watch事件，并给我们提示
        需要安装 
        gulp-notify  // gulp通知的插件，提示出现的错误
        gulp-plumber  // 防止错误引起管道中断
    */
    // 防止错误引起管道中断，出现错误不中断任务
    const plumber = require('gulp-plumber');

    // gulp通知的插件，提示出现的错误
    const notify = require('gulp-notify');


    // 调试文件流来观察那些文件通过了gulp 管道
    const debug = require('gulp-debug');


    // 合并文件
    const concat = require('gulp-concat');


    /* 过滤修改的文件向下传递，只对修改的文件进行编译
        如果多个文件，会过滤掉没有修改的文件，要配合使用 gulp-remember
        gulp-cached是通过对文件设置缓存来进行比较
    */
    const cached = require('gulp-cached');

    /* gulp-cached & gulp-remember 集合使用
        做到只对修改的文件进行编译，
        又能做到当相关联的文件任意一个发生改变的时候，编译所有的相关文件
    */
    const remember = require('gulp-remember');


     

    // 单个文件
    // const entry = './app/less/index.less';

    // 多个文件，以数组形式传入, watch方法路径不要用 './xx'
    // 用 './xx' 开头作为当前路径开始，会导致无法监测到新增文件，所以直接省略掉 './'
    const cfg = {
        entry : ['app/src/less/index.less', 'app/src/less/list.less'],
        output : 'app/src/css'
    };


    // gulp.task()
    gulp.task('less', function(){
        return gulp.src(cfg.entry)
            .pipe( cached('less') ) // 只传递更改过的文件，放在第一位
            .on('error', error) // 让 notify处理错误
            // .pipe( plumber({
            //     errorHandle: notify.onError('error: <%= error.message %>')
            // }) )
            .pipe( debug({
                title: '编译less'
            }) )
    
            .pipe(less())
            .pipe( remember('less') ) // 把所有的文件放回 stream
            .pipe( concat('style.css') ) // 合并文件
            .pipe( gulp.dest(cfg.output) )
    });


    // 监听less文件，自动编译
    gulp.task('watchless', function(){

        gulp.watch( 'app/src/less/**/*.less', ['less'] )
    });



    // 管理 gulp-cached & gulp-remember的缓存：
    gulp.task('watch', function () {
        // 监视与 scripts 任务中同样的文件
        var watcher = gulp.watch('app/src/less/**/*.less', ['less']); 

        watcher.on('change', function (event) {
            console.log(event.type);

            // 如果一个文件被删除了，则将其忘记
            if (event.type === 'deleted') {                   
                // gulp-cached 的删除 api
                delete cached.caches.less[event.path];       
                // gulp-remember 的删除 api
                remember.forget('less', event.path);

                // remember.forget('less', require('gulp-util').replaceExtension(event.path, '.css'));     
            }
        });
    });


