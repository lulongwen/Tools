
    // gulp
    var gulp = require('gulp');

    /* gulp.task() 定义任务
        第一个参数是人物名，第二个参数是这个任务要做的事情
        gulp.task('taskName', function(){
    
        })
    */ 
    // gulp.task('default', function(){
    //     console.log('hello gulp')
    // });


    // 执行 default任务前， 先依次执行数组里的任务
    gulp.task('default', ['task-1', 'task-2'], function(){
        console.log('hello gulp')
    });


    // 执行其他任务， gulp 任务名， 比如 gulp task-1
    gulp.task('task-1', function(){
        console.log('task 1')
    });


    gulp.task('task-2', function(){
        console.log('task 2')
    });
