    
    // gulp
    const gulp = require('gulp');

    // 编译less
    const less = require('gulp-less');


    // 防止错误引起管道中断，出现错误不中断任务
    const plumber = require('gulp-plumber');


    // gulp通知的插件，提示出现的错误
    const notify = require('gulp-notify');


    // 调试文件流来观察那些文件通过了gulp 管道
    const debug = require('gulp-debug');


    /* 过滤修改的文件向下传递，只对修改的文件进行编译
        如果多个文件，会过滤掉没有修改的文件，要配合使用 gulp-remember
    */
    const cached = require('gulp-cached');


    /* 异常处理
        当 less编译语法错误时，会终止编译和 watch，通常要查看命令提示符窗口才知道
        处理出现编译错误，不终止 编译和 watch事件，并给我们提示
        需要安装 
        gulp-notify  // gulp通知的插件，提示出现的错误
        gulp-plumber  // 防止错误引起管道中断
    */ 

    // 单个文件
    // const entry = './app/less/index.less';

    // 多个文件，以数组形式传入, watch方法路径不要用 './xx'
    // 用 './xx' 开头作为当前路径开始，会导致无法监测到新增文件，所以直接省略掉 './'
    const cfg = {
        entry : ['app/src/less/index.less', 'app/src/less/list.less'],
        output : 'app/src/css'
    };


    // gulp.task()
    gulp.task('less', function(){
        return gulp.src(cfg.entry)
            .pipe( cached('less') )
            .pipe( plumber({
                errorHandle: notify.onError('error: <%= error.message %>')
            }) )
            .pipe( debug({
                title: '编译less'
            }) )
            
            .pipe(less())
            .pipe( gulp.dest(cfg.output) )
    });


    // 监听less文件，自动编译
    gulp.task('watchless', function(){

        gulp.watch( 'app/src/less/**/*.less', ['less'] )
    })
