
    // 分离任务到多个文件中
    import requireDir from 'require-dir';

    // require all tasks in tasks, including subfolders
    // 引入所有任务，包括子目录  recurse递归
    requireDir('./tasks', {recurse: true});