
[TOC]
# Gulp
- 前端开发过程中基于流的代码构建工具，减少重复工作，提高工作效率
- Gulp的每个任务都是单独存在的，可以进行单独处理
- 淘宝径向
    + `npm i gulp -D --registry=http://registry.npm.taobao.org`

- --save & --save-dev
    + --save 简写 -S
        * 项目依赖，保存安装版本到 dependencies中，上线还要使用

    + --save-dev 简写 -D
        * 开发依赖，上线不依赖，保存安装版本到 devDependencies中
        * npm update命令会更新安装版本


- Gulp工作流程
    + 文件流 - 文件流 - 文件流
    + 管道的概念：**前一级的输出，变成后一级的输入**
    + Gulp使用的是流操作，一直在内存中处理，直到输出结果
    + Gulp是流为核心的，然后通过管道来输入输出各个子功能的内容以方便后续操作，这样可以提高IO访问效率，在效率上Gulp远胜Grunt
        * Grunt比Gulp更加频繁操作文件系统





## 使用gulp
- gulp通过 gulpfile.js来完成相关任务，因此项目中必须包含 gulpfile.js
- gulpfile.babel.js 可以直接使用 ES6 语法
- 安装gulp
    ```
    npm install gulp -g  // 全局安装
    npm i gulp -D  // 项目依赖安装
    touch gulpfile.babel.js  // 创建 gulpfile.babel.js
    npm init  // 创建 package.json
    ```


## Gulp API 默认的API只有 4个
- gulp.task()
    + 指定任务

- gulp.src()
    + 引入的源文件路径

- gulp.watch()
    + 监听文件变化

- gulp.dest()
    + 输出的文件路径



### gulp.task()
gulp 默认执行 default的任务
    执行单独的特定任务task， 运行 gulp 任务名，例如 gulp less
    执行多个任务 gulp less sass jsmin

```
// default 默认的任务 一个任务
gulp.task('default', ()=>{
	console.log('Hello gulp')
});

// 多个任务，任务是按照数组里面的顺序执行，完成后才执行定义的任务
gulp.task('default', ['less', 'jsmin'], ()=>{
	// 先执行依赖的 less jsmin 最后执行 default
	// 数组里面的执行完，才会执行默认的任务
	console.log('default')
});

```

---



### gulp.src()
- gulp.src() 读取指定模式下的所有文件
- 遵循 Glob规范，类型：String & Array
    + 返回一个流对象，可以理解为当前的匹配模式读取到的文件二进制数据
    + 数据流对象下有一个 .pipe() 方法，即管道的概念

```
// ! 排除的类型
gulp.src(['xml/*.xml', 'json/*.json', '!json/data-*.json'])

// 表示app下所有的文件夹，包括子目录及子目录的文件
gulp.src('app/**/*') 

// 一级目录，不包括2级目录
gulp.src('app/*')

// app目录及 app目录下的二级目录
gulp.src('app/*/*')

```

---



### gulp.watch()
- 任务会一直进行，直到 ctrl+C 手动退出
不要直接在 less 或 sass下 使用 gulp.watch()
- 因为会形成一个循环依赖的情况
- 要在外面加上一个单独的 watch 任务
```
gulp.task('watch',()=>{   
    gulp.watch('src/**/*', ['less', 'sass'])
});
```

---



### gulp.dest()

```

```

---



## Globs 语法
- [globs 匹配语法](https://github.com/isaacs/node-glob)
- Gulp使用 node-glob来从你指定的glob里面获取文件
    + glob工具基于JS, 使用了 minimatch 库来进行匹配

```
app/index.html  精准匹配文件

!js/index.json  排除 js目录下的index.json

* 通配符只能通配一级目录, **  2个* 代表递归加载所有文件
    app/**/*.*
    *.+(js|css) 匹配根目录下所有后缀为 .js & .css

js/*.js  匹配js目录下所有后缀为 .js 的文件

js/*/.js  匹配js目录及其子目录下所有后缀为 .js的文件

\ 是转义的意思
    gulp.src/\*
	gulp.src/\*/\*
	gulp.src/\*\*/\*
	gulp.src/\*.jpg
	gulp.src/\*.{jpg,png}

多个文件
    gulp.src( ['img/\*.{jpg,png}', 'app/index.html'] )

```

