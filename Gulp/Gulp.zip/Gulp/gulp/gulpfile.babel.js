
	import gulp from 'gulp';
	import less from 'gulp-less';
	import csso from 'gulp-csso';

	// server
	import browserSync from 'browser-sync';
	let reload = browserSync.reload;


	gulp.task('less', ()=>{
		console.log('编译less')
		return gulp.src(['./src/less/ui-framework.less'])
			.pipe( less() )
			.pipe( gulp.dest('./src/css') )
	});

	gulp.watch('./src/less/ui-framework.less', ['less']);

	gulp.task('default', ['less'])


	gulp.task('server', ()=>{
		browserSync({
			server:{
				baseDir: './'
			}
		});
	});