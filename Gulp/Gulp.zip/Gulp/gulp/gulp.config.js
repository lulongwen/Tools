
    // gulp 命令会有 gulpfile.babel.js执行， app & dist 文件夹路径如下
    const app = './src';
    const dist = './dist';

    export const paths = {
        entryFile: app,
        distFile: dist,
        html:{
            entry: `${app}/**/*.html`,
            output: dist,
            setting:{

            }
        },
        less: {
            all: `${app}/assets/less/**/*.less`, // all less
            entry: `${app}/assets/less/*.less`, // 编译的less
            output: `${app}/assets/css` , // 打包输出目录
            rev: `${dist}/assets/rev/css`, // md5版本
            settings:{ // 编译less的设置

            }
        },
        js: {
            entry: `${app}/assets/js/**/*`,
            output: `${dist}/js`,
            rev: `${dist}/rev/js`
        },
        images: {
            entry: `${app}/assets/images/**/*`,
            output: `${dist}/images`,
            settings:{
                
            }
        }

    };