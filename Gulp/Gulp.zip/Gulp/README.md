# gulp-ES6项目
- 创建一个主文件，将任务划分为一个个小部分，而不是把所有的任务都放在一个巨大的文件里
```
npm install gulp gulp-clean gulp-imagemin gulp-csso gulp-rev gulp-concat  require-dir gulp-babel babel-preset-es2015 gulp-less gulp-rev-collector browser-sync -D
```

### gulp.task()
```
var gulp = require('gulp');
var rev = require('gulp-rev');
var revReplace = require('gulp-rev-replace');
var useref = require('gulp-useref');
var filter = require('gulp-filter');
var uglify = require('gulp-uglify');
var csso = require('gulp-csso');

gulp.task('default', ()=>{
    let jsFilter = filter('**/*.js', {restore: true});
    let cssFilter = filter('**/*.css', {restore: true});
    // '!**/index.html'，排除 index.html，不能给首页添加版本号
    let indexHtmlFilter = filter(['**/*', '!**/index.html'], {restore: true});
    
    return gulp.src('src/index.html')
        .pipe( useref() )
        .pipe( jsFilter )
        .pipe( uglify() )
        .pipe( jsFilter.restore )

        .pipe( cssFilter )
        .pipe( csso() )
        .pipe( cssFilter.restore )

        .pipe( indexHtmlFilter )
        .pipe( rev() )
        .pipe( indexHtmlFilter.restore )
        .pipe( revReplace() )

        .pipe( gulp.dest('./dist') );
});
```




## Gulp 项目结构
- root 根目录
  - app 前端项目代码
  + css 样式
  + js 脚本文件
    * class 类文件
    * index.js 入口文件
  + html html文件
  * error.ejs 错误模板
  * index.ejs 入口模板
    + express 使用的模板引擎就是 ejs

  - server 服务器代码
  ```
  - express -e .
      + express 脚手架命令
      + -e 表示使用 ejs引擎
      + . 当前目录执行
  ```

  - tasks 自动化任务代码-Gulp前端构建
  ```
  npm init // 创建 package.json

  touch // .babelrc babel编译ES6
  touch gulpfile.babel.js // gulp配置文件

  ```
  + 所有的构建脚本都放在 tasks
  + 要创建很多脚本文件，比如 文件合并，脚本编译，自动刷新浏览器
  + mkdir util 放置常见脚本
    + args.js
    + browser.js 浏览器监听相关，只完成文件的监听
    + build.js
    执行脚本，把所有的任务都串起来，
    那个任务在前，那个任务在后，谁依赖谁，要弄清楚
    1 先编译脚本
    2 启动服务器


  4 根目录要创建的文件
  - package.json npm init -y
  - .babelrc 创建 babel编译文件，babel编译会找这个文件，如果没有，无法编译
  - gulpfile.babel.js
    touch gulpfile.babel.js
    - 表示 构建脚本使用的是 es6的语法
    - 如果不写 babel的话，执行脚本会报错

  gulp-plumber 处理文件信息流
  gulp-util gulp工具

  把所有任务都串起来，谁在前，谁在后，谁依赖谁，要弄清楚
  1 先清空 dest的文件夹
  2 然后编译 less ，编译模板
  3 执行脚本，紧接着启动服务器
  总之，服务器要在最后启动

  yargs 对命令行参数进行解析
  yargs 是 node.js命令行框架
      - 建立 交互式的命令行工具，通过解析参数生成一个优雅的界面
  gulp -production 就是选项部分 .option('production')
      - 如果没有输入值，默认就是 false
      命令行直接输入 gulp 会去找 default.js
  .argv 以字符串形式解析

  // 安装包
  npm i gulp gulp-if gulp-concat gulp-livereload webpack webpack-stream vinyl-named gulp-plumber gulp-rename gulp-uglify gulp-util yargs -D

  // 安装包 
  npm i require-dir gulp-live-server del gulp-sequence -D

  del 删除文件和文件夹

  // babel
  npm i babel-loader babel-core babel-preset-env babel-preset-es2015 -D

  安装 connect-livereload 
    npm i connect-livereload -D

  运行
  gulp --watch
